// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

// Stub to satisfy d3dx12.h include
#pragma once
#include <wsl/wrladapter.h>