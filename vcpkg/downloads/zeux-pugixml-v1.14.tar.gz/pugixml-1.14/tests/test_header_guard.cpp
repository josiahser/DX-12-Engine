// Tests header guards
#include "../src/pugixml.hpp"
#include "../src/pugixml.hpp"
