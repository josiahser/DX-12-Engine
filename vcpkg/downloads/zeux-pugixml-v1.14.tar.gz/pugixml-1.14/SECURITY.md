# Security Policy

## Supported Versions

Please verify that the vulnerabilities reported can be reproduced on the [latest released version](https://github.com/zeux/pugixml/releases).

## Reporting a Vulnerability

Vulnerabilities can be reported via e-mail to the [project maintainer](https://github.com/zeux).
